﻿<?php
declare(strict_types=1);
$root=$argv[1]; require $root.'/vendor/autoload.php';
$app=require $root.'/bootstrap/app.php'; $app->make(Illuminate\Contracts\Console\Kernel::class)->bootstrap();
$manifest=json_decode(file_get_contents(__DIR__.'/fixture.json'),true,flags:JSON_THROW_ON_ERROR);
use Illuminate\Support\Facades\DB;
use App\Support\Tenancy\CompanyContext;
if(!str_starts_with(DB::connection()->getDatabaseName(),'accounting_p8_tmp_') || (int)config('database.connections.mysql.port')!==3318)throw new RuntimeException('Wrong local fixture');
$owner=App\Models\User::findOrFail($manifest['owner_id']); $company=App\Models\Company::findOrFail($manifest['company_id']); auth()->login($owner);app(CompanyContext::class)->setCompany($company,$owner);
if(($argv[2]??'')==='policy') {App\Models\AiCompanyPolicy::where('company_id',$company->id)->update(['enabled'=>($argv[3]??'')==='on']);echo 'Synthetic policy updated';exit;}
if(($argv[2]??'')==='enable') {try{$q=app(App\Application\AI\DeepSeekQuickConnect::class);$p=App\Models\AiCompanyPolicy::firstOrFail();echo 'transition='.($q->needsTransition($company)?'yes':'no')."\n";$q->enableCompany($company,$owner,'B1-local-fixture-only!',$p->revision);echo 'enabled='.($p->fresh()->enabled?'yes':'no');}catch(App\Application\AI\AssistantUnavailable $e){echo 'reason='.$e->diagnosticReason();}exit;}
$fingerprint=function(){ $out=[];foreach(['posting_batches','posting_lines','stock_movements','inventory_balances','inventory_cost_states','sales_invoices','sales_invoice_lines','purchases','purchase_lines','customer_payments','customer_payment_allocations','vendor_payments','vendor_payment_allocations','checks']as $table){$rows=DB::table($table)->orderBy('id')->get();$out[$table]=['rows'=>$rows->count(),'sha256'=>hash('sha256',json_encode($rows))];}return $out;};
$before=$fingerprint();$results=[];
foreach(['accounting'=>App\Services\Accounting\AccountingReconciliationService::class,'inventory'=>App\Services\Inventory\InventoryReconciliationService::class,'sales'=>App\Services\Sales\SalesReconciliationService::class,'money'=>App\Services\Money\MoneyReconciliationService::class,'payables'=>App\Services\Purchasing\PayablesReconciliationService::class,'phase7'=>App\Services\Accounting\Phase7ReconciliationService::class] as $domain=>$class){$t=hrtime(true);$r=$domain==='inventory'?app($class)->auditCompany($company):app($class)->reconcile($company);$results[$domain]=['healthy'=>$r->isHealthy,'violations'=>$domain==='inventory'?$r->discrepancies:$r->violations,'stats'=>$r->stats??[],'ms'=>round((hrtime(true)-$t)/1e6,3)];}
$after=$fingerprint();
$plans=[];
foreach(['barcode'=>['select * from product_barcodes where company_id = ? and barcode = ? limit 1',[$company->id,'B1SCAN1']],'policy'=>['select * from ai_company_policies where company_id = ? limit 1',[$company->id]],'membership'=>['select * from company_user where company_id = ? and user_id = ? and status = ? limit 1',[$company->id,$owner->id,'active']],'product_search'=>['select id, sku, name_ar, name_en from products where company_id = ? and active = 1 and (name_ar like ? or name_en like ? or sku like ?) limit 20',[$company->id,'%Soap%','%Soap%','%Soap%']]] as $label=>[$sql,$bindings]){$plans[$label]=['sql'=>$sql,'plan'=>DB::select('EXPLAIN '.$sql,$bindings)];}
echo json_encode(['database_version'=>DB::selectOne('select version() as v')->v,'fixture'=>'owned local synthetic merchant','reconciliations'=>$results,'read_only'=>$before===$after,'fingerprints'=>$after,'plans'=>$plans],JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES),"\n";
