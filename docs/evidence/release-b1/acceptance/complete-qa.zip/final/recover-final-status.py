from pathlib import Path
import json,datetime,subprocess,hashlib
l=Path(__file__).parent;q=l/'qa-11'
w=Path(r'C:/Users/bassa/AppData/Local/Codex/google-worker-workspaces/r_5b78e9902b6de712cd2bc2e6/task_19f8f1bf6c2f45ec9ff5ad9d4038b88d/worktree')
s=json.loads((q/'status.json').read_text());o=json.loads((q/'schema-ownership.json').read_text())
assert s['qa_exit_code'] is None and o['composer_exit_code']==0
assert o['primary_counts_unchanged'] and o['schema_absent_after_cleanup']
assert '3440 passed' in (q/'composer-qa.log').read_text(encoding='utf-8-sig').replace('\x1b[32;1m','').replace('\x1b[39;22m','')
def git(*args):return subprocess.check_output(['git',*args],cwd=w,text=True).strip()
assert git('rev-parse','HEAD')==s['source_head']
assert not git('diff','HEAD','--binary')
assert hashlib.sha256((w/'package-lock.json').read_bytes()).hexdigest()==s['lock_sha256']
before=json.loads((q/'reconcile-before.json').read_text(encoding='utf-8-sig'))
after=json.loads((q/'reconcile-after.json').read_text(encoding='utf-8-sig'))
assert before['fingerprints']==after['fingerprints'] and after['read_only']
assert all(r['healthy'] and not r['violations'] for r in after['reconciliations'].values())
assert (q/'reconcile-recovery-exit.txt').read_text().strip()=='0'
assert (q/'recovery-shutdown-exit.txt').read_text().strip()=='0'
(q/'status-before-recovery.json').write_text(json.dumps(s,indent=2)+'\n')
s.update(state='completed_with_wrapper_recovery',qa_exit_code=o['composer_exit_code'],reconciliation_after_exit=0,database_shutdown_exit=0,completed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),outer_wrapper_completed=False,qa_exit_source='Actual Symfony Process getExitCode captured in schema-ownership.json before disposable schema cleanup',recovery='Outer pythonw wrapper disappeared after Composer completed; cause unverified. Codex separately ran six read-only reconciliations, verified immutable source and lock, and gracefully stopped the identity-verified owned MariaDB. No outer-wrapper exit status is claimed.')
(q/'status.json').write_text(json.dumps(s,indent=2)+'\n')
print(json.dumps(s,indent=2))
