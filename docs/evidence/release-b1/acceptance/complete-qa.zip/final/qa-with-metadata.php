﻿<?php
declare(strict_types=1);
$root=$argv[1];require $root.'/vendor/autoload.php';
foreach(['APP_ENV'=>'testing','PHASE8_ALLOW_DISPOSABLE_DB'=>'1','PHASE8_TEST_DB_HOST'=>'127.0.0.1','PHASE8_TEST_DB_PORT'=>'3318','PHASE8_TEST_DB_USERNAME'=>'root','PHASE8_TEST_DB_EMPTY_PASSWORD'=>'1'] as $key=>$value){putenv("$key=$value");$_ENV[$key]=$value;$_SERVER[$key]=$value;}
$schema=Tests\Support\DisposableMariaDbSchema::create();
$name=$schema->schemaName();
$metadata=['schema'=>$name,'host'=>'127.0.0.1','port'=>3318,'owned_fresh_schema'=>true,'composer_exit_code'=>null,'primary_counts_before'=>null,'primary_counts_after'=>null,'primary_counts_unchanged'=>null,'schema_absent_after_cleanup'=>null];
$save=function()use(&$metadata):void{file_put_contents(getenv('B1_QA_METADATA_PATH'),json_encode($metadata,JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES)."\n");};
$pdo=new PDO('mysql:host=127.0.0.1;port=3318;charset=utf8mb4','root','',[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION]);
$snapshot=function()use($pdo,$name):array{
 if(!preg_match('/^accounting_p8_tmp_[a-f0-9]{12}$/D',$name)){throw new RuntimeException('Refusing an unowned schema');}
 $out=[];foreach(['companies','users','sales_invoices','purchases','stock_movements','posting_batches','posting_lines','customer_payments','vendor_payments','checks']as$table){$out[$table]=(int)$pdo->query("SELECT COUNT(*) FROM `$name`.`$table`")->fetchColumn();}return$out;
};
$exit=1;
try{
 // Local runner startup may exceed the helper's 120-second interactive budget.
 // Same migration command, private ownership environment and permission provisioner.
 $env=$schema->environment();
 $migration=new Symfony\Component\Process\Process([PHP_BINARY,'artisan','migrate','--database=mysql','--force'],$root,$env);
 $migration->setTimeout(600)->mustRun(function($type,$buffer){echo $buffer;});
 $provision=new Symfony\Component\Process\Process([PHP_BINARY,'-r','require "vendor/autoload.php"; $app=require "bootstrap/app.php"; $app->make(Illuminate\\Contracts\\Console\\Kernel::class)->bootstrap(); app(App\\Services\\Tenancy\\CompanyRoleService::class)->ensurePermissionsExist();'],$root,$env);
 $provision->setTimeout(120)->mustRun(function($type,$buffer){echo $buffer;});
 $metadata['primary_counts_before']=$snapshot();$save();
 $env=array_replace($env,['AI_ASSISTANT_ENABLED'=>'false','AI_PROVIDER_APPROVED'=>'false','AI_ASSISTANT_PROVIDER'=>'none','AI_TURN_ENABLED'=>'false','AI_DAILY_BRIEFING_ENABLED'=>'false','AI_QUESTIONS_ENABLED'=>'false']);
 foreach(Tests\Support\DisposableMariaDbSchema::testSettings() as$key=>$value)$env['PHASE8_TEST_DB_'.$key]=$value;
 $env['PATH']=dirname(PHP_BINARY).PATH_SEPARATOR.getenv('PATH');
 $targets=array_slice($argv,2);
 $metadata['command']=$targets===[]?'composer qa':'focused phpunit';
 $command=$targets===[]?[PHP_BINARY,'[local-tool-path]','qa']:array_merge([PHP_BINARY,'vendor/bin/phpunit'],$targets);
 $process=new Symfony\Component\Process\Process($command,$root,$env);$process->setTimeout(10800);
 $process->run(function($type,$buffer){echo$buffer;});
 $metadata['composer_exit_code']=$targets===[]?$process->getExitCode():null;
 $metadata['phpunit_exit_code']=$targets===[]?null:$process->getExitCode();$exit=$process->getExitCode()??1;
 $metadata['primary_counts_after']=$snapshot();
 $metadata['primary_counts_unchanged']=$metadata['primary_counts_before']===$metadata['primary_counts_after'];
 if(!$metadata['primary_counts_unchanged'])$exit=1;
}finally{
 $schema->drop();
 $q=$pdo->prepare('SELECT COUNT(*) FROM information_schema.schemata WHERE schema_name=?');$q->execute([$name]);
 $metadata['schema_absent_after_cleanup']=(int)$q->fetchColumn()===0;$save();
 echo "Owned QA schema cleaned.\n";
}
exit($exit);
