import pathlib,subprocess,os,json,datetime,socket,time,hashlib,sys
base=pathlib.Path(__file__).parent
local=base.parent
attempt=sys.argv[1] if len(sys.argv)>1 else 'qa-02'
targets=sys.argv[2:]
assert len(attempt)==5 and attempt.startswith('qa-') and attempt[3:].isdigit()
out=base/attempt
assert not (out/'status.json').exists(), 'Never overwrite a QA attempt'
out.mkdir(exist_ok=True)
release=pathlib.Path(r'C:/Users/bassa/AppData/Local/Codex/google-worker-workspaces/r_5b78e9902b6de712cd2bc2e6/task_19f8f1bf6c2f45ec9ff5ad9d4038b88d/worktree')
php=pathlib.Path(r'C:/Users/bassa/AppData/Local/Microsoft/WinGet/Packages/PHP.PHP.8.4_Microsoft.Winget.Source_8wekyb3d8bbwe/php.exe')
mysql=pathlib.Path(r'C:/xampp/mysql/bin/mysql.exe')
admin=pathlib.Path(r'C:/xampp/mysql/bin/mysqladmin.exe')
flags=subprocess.CREATE_NO_WINDOW
env=os.environ.copy()
env.update(PHP_INI_SCAN_DIR=str(local/'php-ini'), COMPOSER_PROCESS_TIMEOUT='10800', PHASE10_PDFTOOLS_DIR=str(local/'python-tools'), PATH=str(php.parent)+';'+env.get('PATH',''), B1_QA_METADATA_PATH=str(out/'schema-ownership.json'))
env.update(AI_ASSISTANT_ENABLED='false', AI_PROVIDER_APPROVED='false', AI_ASSISTANT_PROVIDER='none', AI_TURN_ENABLED='false', AI_QUESTIONS_ENABLED='false', AI_DAILY_BRIEFING_ENABLED='false')
state={'state':'starting','started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'wrapper_pid':os.getpid(),'launcher':'Windows Task Scheduler pythonw.exe; CREATE_NO_WINDOW for all child processes','command':'PHP 8.4 qa-with-metadata.php RELEASE -> PHP 8.4 composer.phar qa','qa_exit_code':None,'database_pid':None,'database_shutdown_exit':None,'completed_utc':None,'error':None}
state['mode']='focused phpunit' if targets else 'complete composer qa'
state['targets']=targets
def save():
 temp=out/'status.tmp';temp.write_text(json.dumps(state,indent=2)+'\n',encoding='utf-8');os.replace(temp,out/'status.json')
def command(args):return subprocess.check_output(args,cwd=release,creationflags=flags,env=env,text=True).strip()
def run(args,name,timeout=7200):
 with (out/name).open('wb') as stdout, (out/(name+'.stderr')).open('wb') as stderr:
  p=subprocess.Popen([str(x) for x in args],cwd=release,env=env,creationflags=flags,stdout=stdout,stderr=stderr)
  if name=='composer-qa.log':state['qa_pid']=p.pid;save()
  return p.wait(timeout=timeout)
database=None
exit_code=1
try:
 state['source_head']=command(['git','rev-parse','HEAD'])
 state['source_tree']=command(['git','rev-parse','HEAD^{tree}'])
 tracked_diff=command(['git','diff','HEAD','--binary'])
 state['tracked_diff_sha256']=hashlib.sha256(tracked_diff.encode('utf-8')).hexdigest()
 if not targets:assert not tracked_diff,'Complete QA requires committed, clean tracked source'
 state['lock_sha256']=hashlib.sha256((release/'package-lock.json').read_bytes()).hexdigest();save()
 with socket.socket() as test:
  test.settimeout(.3)
  if test.connect_ex(('127.0.0.1',3318))==0:raise RuntimeError('Port3318 already in use; refusing to adopt another process')
 with (out/'mariadb.stdout.log').open('wb') as dbout,(out/'mariadb.stderr.log').open('wb') as dberr:
  database=subprocess.Popen([r'C:/xampp/mysql/bin/mysqld.exe','--defaults-file='+str(local/'mariadb/my.ini'),'--bind-address=127.0.0.1','--port=3318','--console'],creationflags=flags,stdout=dbout,stderr=dberr)
 state['database_pid']=database.pid;save()
 for i in range(60):
  ping=subprocess.run([str(admin),'--host=127.0.0.1','--port=3318','--user=root','ping'],creationflags=flags,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
  if ping.returncode==0:break
  if database.poll() is not None:raise RuntimeError('Owned database exited before readiness')
  time.sleep(2)
 else:raise RuntimeError('Owned disposable server startup timeout')
 subprocess.run([str(mysql),'--host=127.0.0.1','--port=3318','--user=root','-e','SET GLOBAL innodb_flush_log_at_trx_commit=2'],creationflags=flags,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE,check=True)
 state['reconciliation_before_exit']=run([php,local/'inspect.php',release],'reconcile-before.json')
 if state['reconciliation_before_exit']!=0:raise RuntimeError('Synthetic fixture reconciliation preflight failed')
 state['state']='running_composer_qa';save()
 state['qa_exit_code']=run([php,base/'qa-with-metadata.php',release,*targets],'composer-qa.log',timeout=10800)
 state['state']='reconciling_after_qa';save()
 state['reconciliation_after_exit']=run([php,local/'inspect.php',release],'reconcile-after.json')
 assert state['source_head']==command(['git','rev-parse','HEAD']), 'HEAD changed during QA'
 assert state['tracked_diff_sha256']==hashlib.sha256(command(['git','diff','HEAD','--binary']).encode('utf-8')).hexdigest(),'Tracked source changed during QA'
 assert state['lock_sha256']==hashlib.sha256((release/'package-lock.json').read_bytes()).hexdigest(),'Lock changed during QA'
 exit_code=state['qa_exit_code']
 if state['reconciliation_after_exit']!=0:exit_code=1
 state['state']='completed' if exit_code==0 else 'completed_with_failure'
except BaseException as error:
 state.update(state='failed',error=repr(error));exit_code=1
finally:
 if database is not None and database.poll() is None:
  shutdown=subprocess.run([str(admin),'--host=127.0.0.1','--port=3318','--user=root','shutdown'],creationflags=flags,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
  state['database_shutdown_exit']=shutdown.returncode
 state['completed_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
sys.exit(exit_code)
